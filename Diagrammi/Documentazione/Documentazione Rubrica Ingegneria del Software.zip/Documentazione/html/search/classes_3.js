var searchData=
[
  ['rubrica_0',['Rubrica',['../classdata_1_1_rubrica.html',1,'data']]]
];
