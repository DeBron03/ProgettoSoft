var searchData=
[
  ['aggiungicontatto_0',['aggiungiContatto',['../classcontroller_1_1_aggiunta_contatto_controller.html#a23ed7e218e4175cec39f59653b017b19',1,'controller.AggiuntaContattoController.aggiungiContatto()'],['../classdata_1_1_rubrica.html#a50684d544f111d9fb75bbd136fa8537c',1,'data.Rubrica.aggiungiContatto()']]],
  ['aggiuntacontattocontroller_1',['AggiuntaContattoController',['../classcontroller_1_1_aggiunta_contatto_controller.html',1,'controller']]],
  ['aggiuntacontattocontroller_2ejava_2',['AggiuntaContattoController.java',['../_aggiunta_contatto_controller_8java.html',1,'']]],
  ['annulla_3',['annulla',['../classcontroller_1_1_aggiunta_contatto_controller.html#a2ea80cc23d71f50b06d9dfa263ff037d',1,'controller.AggiuntaContattoController.annulla()'],['../classannullaoperazione_1_1_annulla_operazione.html#a99386be72c44362311bd11defe6e6d86',1,'annullaoperazione.AnnullaOperazione.annulla()'],['../classcontroller_1_1_modifica_contatto_controller.html#a78bc7f0dce451c4defc44642a4e632b9',1,'controller.ModificaContattoController.annulla()'],['../classdata_1_1_rubrica.html#ae1c0e35bb1155fc2287b574c464750a4',1,'data.Rubrica.annulla()'],['../classcontroller_1_1_visualizza_singolo_contatto_controller.html#ae14abf4e6e72cd7b7db721c107c7beec',1,'controller.VisualizzaSingoloContattoController.annulla()']]],
  ['annullaoperazione_4',['AnnullaOperazione',['../classannullaoperazione_1_1_annulla_operazione.html',1,'annullaoperazione.AnnullaOperazione'],['../classannullaoperazione_1_1_annulla_operazione.html#ade1529fe9abf4edff4c941b393f24ee1',1,'annullaoperazione.AnnullaOperazione.AnnullaOperazione()']]],
  ['applicazione_5',['Applicazione',['../classmain_1_1_applicazione.html',1,'main']]],
  ['applicazione_2ejava_6',['Applicazione.java',['../_applicazione_8java.html',1,'']]]
];
