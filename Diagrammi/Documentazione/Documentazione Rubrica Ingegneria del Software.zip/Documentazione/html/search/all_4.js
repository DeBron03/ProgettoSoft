var searchData=
[
  ['getcognome_0',['getCognome',['../classdata_1_1_contatto.html#ab25735d38a471a1da03d1b09fc6398ca',1,'data::Contatto']]],
  ['getcompleanno_1',['getCompleanno',['../classdata_1_1_contatto.html#a719e7a6eb8ab7adc970d2c76f7037616',1,'data::Contatto']]],
  ['getemail1_2',['getEmail1',['../classdata_1_1_contatto.html#aa75ef4b2b2eee54227d979fc42092ccf',1,'data::Contatto']]],
  ['getemail2_3',['getEmail2',['../classdata_1_1_contatto.html#a020186d179dddf41807df91e34dd2498',1,'data::Contatto']]],
  ['getemail3_4',['getEmail3',['../classdata_1_1_contatto.html#a566a10ca79ed9b289b9741fbd4f63656',1,'data::Contatto']]],
  ['getindirizzo_5',['getIndirizzo',['../classdata_1_1_contatto.html#a7d1f8a6099705ecdd98010ff21f899af',1,'data::Contatto']]],
  ['getnome_6',['getNome',['../classdata_1_1_contatto.html#a01ad87419442ba7699c6c3fecc67a2a9',1,'data::Contatto']]],
  ['getsocietà_7',['getSocietà',['../classdata_1_1_contatto.html#a78ae469a565e6114fedc2284f47c69b8',1,'data::Contatto']]],
  ['gettelefono1_8',['getTelefono1',['../classdata_1_1_contatto.html#a50b37b4972e79922220c69158eff0402',1,'data::Contatto']]],
  ['gettelefono2_9',['getTelefono2',['../classdata_1_1_contatto.html#a7d77b502c70b11d2639f0060d3e65f3b',1,'data::Contatto']]],
  ['gettelefono3_10',['getTelefono3',['../classdata_1_1_contatto.html#a89b7b03b6f73f333ca3c1bec118cd024',1,'data::Contatto']]]
];
