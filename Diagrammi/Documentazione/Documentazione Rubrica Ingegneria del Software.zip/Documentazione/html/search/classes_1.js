var searchData=
[
  ['contatto_0',['Contatto',['../classdata_1_1_contatto.html',1,'data']]]
];
