var searchData=
[
  ['maininterfacecontroller_0',['MainInterfaceController',['../classcontroller_1_1_main_interface_controller.html',1,'controller']]],
  ['modificacontattocontroller_1',['ModificaContattoController',['../classcontroller_1_1_modifica_contatto_controller.html',1,'controller']]]
];
