var searchData=
[
  ['aggiuntacontattocontroller_0',['AggiuntaContattoController',['../classcontroller_1_1_aggiunta_contatto_controller.html',1,'controller']]],
  ['annullaoperazione_1',['AnnullaOperazione',['../classannullaoperazione_1_1_annulla_operazione.html',1,'annullaoperazione']]],
  ['applicazione_2',['Applicazione',['../classmain_1_1_applicazione.html',1,'main']]]
];
