var searchData=
[
  ['importacontatto_0',['importaContatto',['../classcontroller_1_1_main_interface_controller.html#a8637c02a2269d46baef22454bd60f678',1,'controller.MainInterfaceController.importaContatto()'],['../classdata_1_1_rubrica.html#ac61c59920a86eec2c5277ef3118abf72',1,'data.Rubrica.importaContatto()']]],
  ['initialize_1',['initialize',['../classcontroller_1_1_aggiunta_contatto_controller.html#a3d23ca7f3fadf263ddd0f660d5682d3e',1,'controller.AggiuntaContattoController.initialize()'],['../classcontroller_1_1_main_interface_controller.html#ad1ffaf7c00240b70bfc4ba945f1fa163',1,'controller.MainInterfaceController.initialize()'],['../classcontroller_1_1_modifica_contatto_controller.html#a13746b44533611a532fd209b46e07071',1,'controller.ModificaContattoController.initialize()'],['../classcontroller_1_1_visualizza_singolo_contatto_controller.html#a66ba9001730ac9c2a7990c7ad6a3c621',1,'controller.VisualizzaSingoloContattoController.initialize()']]]
];
