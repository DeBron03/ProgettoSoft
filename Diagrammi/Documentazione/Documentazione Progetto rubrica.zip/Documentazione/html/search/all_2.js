var searchData=
[
  ['displayaggiungicontatto_0',['displayAggiungiContatto',['../classcontroller_1_1_main_interface_controller.html#aaa197fd31a4fc68b4ea0ee0ef3ec5bf5',1,'controller::MainInterfaceController']]],
  ['displaymodificacontatto_1',['displayModificaContatto',['../classcontroller_1_1_visualizza_singolo_contatto_controller.html#acf0bf2e311a2d32915394dcc2d63d839',1,'controller::VisualizzaSingoloContattoController']]],
  ['displayvisualizzasingolocontatto_2',['displayVisualizzaSingoloContatto',['../classcontroller_1_1_main_interface_controller.html#a3624cd01696e6cf4b33f193c7259f7fb',1,'controller::MainInterfaceController']]]
];
