var searchData=
[
  ['eliminacontatto_0',['eliminaContatto',['../classdata_1_1_rubrica.html#acde304846946d8a2da82dce0181eb346',1,'data.Rubrica.eliminaContatto()'],['../classcontroller_1_1_visualizza_singolo_contatto_controller.html#ad04ad5b25e98d179c8804e346c3c2f25',1,'controller.VisualizzaSingoloContattoController.eliminaContatto()']]],
  ['esportacontatto_1',['esportaContatto',['../classcontroller_1_1_main_interface_controller.html#ab264bb4dad1f03d85e558dcd089c1b5d',1,'controller.MainInterfaceController.esportaContatto()'],['../classdata_1_1_rubrica.html#a70f79f500b092c0411f03e33dcbccbe4',1,'data.Rubrica.esportaContatto()']]]
];
