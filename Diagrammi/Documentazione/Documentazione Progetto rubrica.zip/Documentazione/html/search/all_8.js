var searchData=
[
  ['salvastato_0',['salvaStato',['../classannullaoperazione_1_1_annulla_operazione.html#ad0af26ad0c559a56b7ecf22cd5126724',1,'annullaoperazione::AnnullaOperazione']]],
  ['setcognome_1',['setCognome',['../classdata_1_1_contatto.html#a39800ceb646397c7980e8163ac8d9955',1,'data::Contatto']]],
  ['setcompleanno_2',['setCompleanno',['../classdata_1_1_contatto.html#a16f3364cfa6259c5e9ca232db210218f',1,'data::Contatto']]],
  ['setemail1_3',['setEmail1',['../classdata_1_1_contatto.html#a1483d77d5d5089673ec8d2f4000ce9b7',1,'data::Contatto']]],
  ['setemail2_4',['setEmail2',['../classdata_1_1_contatto.html#a73b1e2a21feba9ff0a50382b7340f9dc',1,'data::Contatto']]],
  ['setemail3_5',['setEmail3',['../classdata_1_1_contatto.html#a2c53463f1f0d62ac7eebaa6effa36a28',1,'data::Contatto']]],
  ['setindirizzo_6',['setIndirizzo',['../classdata_1_1_contatto.html#a21d00c42fd957dfa5ee1aa880115d02d',1,'data::Contatto']]],
  ['setnome_7',['setNome',['../classdata_1_1_contatto.html#ac0fec2133826e6b6622730f6be91b4e4',1,'data::Contatto']]],
  ['setsocietà_8',['setSocietà',['../classdata_1_1_contatto.html#a178ede55ee6c88cf6ba1d7e5b4eb3a74',1,'data::Contatto']]],
  ['settelefono1_9',['setTelefono1',['../classdata_1_1_contatto.html#a26fbdc3db443e2948c3ad2da047fc6eb',1,'data::Contatto']]],
  ['settelefono2_10',['setTelefono2',['../classdata_1_1_contatto.html#a2ea46e77f2707208c87431c66ec1211c',1,'data::Contatto']]],
  ['settelefono3_11',['setTelefono3',['../classdata_1_1_contatto.html#a081782764a348efd2ff9fe149570b896',1,'data::Contatto']]],
  ['start_12',['start',['../classmain_1_1_applicazione.html#acbd882b5bb221764799d6d08e9e844f1',1,'main::Applicazione']]]
];
