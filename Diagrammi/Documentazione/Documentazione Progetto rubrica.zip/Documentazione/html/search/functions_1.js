var searchData=
[
  ['contatto_0',['Contatto',['../classdata_1_1_contatto.html#a091da99d2def84bba912873149b9f225',1,'data::Contatto']]]
];
