var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../classcontroller_1_1_main_interface_controller.html#a2e896a615959245327f979dafa9b1db2',1,'controller.MainInterfaceController.ricercaContatto()'],['../classdata_1_1_rubrica.html#a68c230abd5c511e9f4330fa8c29dea82',1,'data.Rubrica.ricercaContatto()']]],
  ['rubrica_1',['Rubrica',['../classdata_1_1_rubrica.html',1,'data.Rubrica'],['../classdata_1_1_rubrica.html#a71e8335491bc3741deae1e70f16e725c',1,'data.Rubrica.Rubrica()']]],
  ['rubrica_2ejava_2',['Rubrica.java',['../_rubrica_8java.html',1,'']]]
];
