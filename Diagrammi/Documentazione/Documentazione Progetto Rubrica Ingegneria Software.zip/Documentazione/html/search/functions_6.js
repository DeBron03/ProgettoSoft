var searchData=
[
  ['main_0',['main',['../classmain_1_1_applicazione.html#a5904d3d74773c46a2d92cb8c87c4bab1',1,'main::Applicazione']]],
  ['modificacontatto_1',['modificaContatto',['../class_interface_1_1controller_1_1_modifica_contatto_controller.html#a01a42a8607858aab8ea73351b9bd45ae',1,'Interface.controller.ModificaContattoController.modificaContatto()'],['../classdata_1_1_rubrica.html#a9417e1ec62c12093233fad9a5ded3d8b',1,'data.Rubrica.modificaContatto(Contatto c)']]],
  ['mostrarubrica_2',['mostraRubrica',['../classdata_1_1_rubrica.html#a9440ad0632f34f86531e46fd7530b82f',1,'data::Rubrica']]]
];
