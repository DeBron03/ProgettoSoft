var searchData=
[
  ['visualizzacontatto_0',['visualizzaContatto',['../classdata_1_1_rubrica.html#a63a3c465cb1dd645555f6852a0e7db35',1,'data::Rubrica']]],
  ['visualizzasingolocontattocontroller_1',['VisualizzaSingoloContattoController',['../class_interface_1_1controller_1_1_visualizza_singolo_contatto_controller.html',1,'Interface::controller']]],
  ['visualizzasingolocontattocontroller_2ejava_2',['VisualizzaSingoloContattoController.java',['../_visualizza_singolo_contatto_controller_8java.html',1,'']]]
];
