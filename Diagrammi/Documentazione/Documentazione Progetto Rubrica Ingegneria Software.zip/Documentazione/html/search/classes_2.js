var searchData=
[
  ['maininterfacecontroller_0',['MainInterfaceController',['../class_interface_1_1controller_1_1_main_interface_controller.html',1,'Interface::controller']]],
  ['modificacontattocontroller_1',['ModificaContattoController',['../class_interface_1_1controller_1_1_modifica_contatto_controller.html',1,'Interface::controller']]]
];
