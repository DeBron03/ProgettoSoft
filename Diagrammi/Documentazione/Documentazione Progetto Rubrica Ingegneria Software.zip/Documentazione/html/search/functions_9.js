var searchData=
[
  ['visualizzacontatto_0',['visualizzaContatto',['../classdata_1_1_rubrica.html#a63a3c465cb1dd645555f6852a0e7db35',1,'data::Rubrica']]]
];
