var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../class_interface_1_1controller_1_1_main_interface_controller.html#a6220a3ca4c208a8ac5e9f5a72ced3394',1,'Interface.controller.MainInterfaceController.ricercaContatto()'],['../classdata_1_1_rubrica.html#a68c230abd5c511e9f4330fa8c29dea82',1,'data.Rubrica.ricercaContatto()']]],
  ['rubrica_1',['Rubrica',['../classdata_1_1_rubrica.html',1,'data.Rubrica'],['../classdata_1_1_rubrica.html#a71e8335491bc3741deae1e70f16e725c',1,'data.Rubrica.Rubrica()']]],
  ['rubrica_2ejava_2',['Rubrica.java',['../_rubrica_8java.html',1,'']]]
];
