var searchData=
[
  ['visualizzasingolocontattocontroller_0',['VisualizzaSingoloContattoController',['../class_interface_1_1controller_1_1_visualizza_singolo_contatto_controller.html',1,'Interface::controller']]]
];
