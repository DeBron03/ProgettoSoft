var searchData=
[
  ['displayaggiungicontatto_0',['displayAggiungiContatto',['../class_interface_1_1controller_1_1_main_interface_controller.html#a2a0879310030ef8dcec53aadf8f8cd9c',1,'Interface::controller::MainInterfaceController']]],
  ['displaymodificacontatto_1',['displayModificaContatto',['../class_interface_1_1controller_1_1_visualizza_singolo_contatto_controller.html#ab7b5b466d5326feba6cbb77817ead2a6',1,'Interface::controller::VisualizzaSingoloContattoController']]],
  ['displayvisualizzasingolocontatto_2',['displayVisualizzaSingoloContatto',['../class_interface_1_1controller_1_1_main_interface_controller.html#aeb7ba93825c0b146847a00ea4faa9d37',1,'Interface::controller::MainInterfaceController']]]
];
