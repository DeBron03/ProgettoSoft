var searchData=
[
  ['aggiuntacontattocontroller_0',['AggiuntaContattoController',['../class_interface_1_1controller_1_1_aggiunta_contatto_controller.html',1,'Interface::controller']]],
  ['annullaoperazione_1',['AnnullaOperazione',['../classannullaoperazione_1_1_annulla_operazione.html',1,'annullaoperazione']]],
  ['applicazione_2',['Applicazione',['../classmain_1_1_applicazione.html',1,'main']]]
];
