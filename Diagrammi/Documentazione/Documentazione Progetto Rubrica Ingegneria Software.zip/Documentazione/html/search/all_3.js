var searchData=
[
  ['eliminacontatto_0',['eliminaContatto',['../classdata_1_1_rubrica.html#acde304846946d8a2da82dce0181eb346',1,'data.Rubrica.eliminaContatto()'],['../class_interface_1_1controller_1_1_visualizza_singolo_contatto_controller.html#ad3257143713616cead277da22e2816f0',1,'Interface.controller.VisualizzaSingoloContattoController.eliminaContatto()']]],
  ['esportacontatto_1',['esportaContatto',['../class_interface_1_1controller_1_1_main_interface_controller.html#a6a268184dea4f4d5fc185ff2b05db172',1,'Interface.controller.MainInterfaceController.esportaContatto()'],['../classdata_1_1_rubrica.html#a70f79f500b092c0411f03e33dcbccbe4',1,'data.Rubrica.esportaContatto()']]]
];
