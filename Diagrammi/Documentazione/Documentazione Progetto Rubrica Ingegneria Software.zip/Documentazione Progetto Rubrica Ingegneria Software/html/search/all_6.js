var searchData=
[
  ['main_0',['main',['../classcom_1_1francesco_1_1rubrica_1_1_main_1_1_app.html#ad4c5bd9c9275dd0f69cb53ea62b41bfc',1,'com::francesco::rubrica::Main::App']]],
  ['maininterfacecontroller_1',['MainInterfaceController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_main_interface_controller.html',1,'com::francesco::rubrica::Interface']]],
  ['modificacontatto_2',['modificaContatto',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#accca283e46426e17742aae366770bf87',1,'com::francesco::rubrica::Data::Rubrica']]],
  ['modificacontattocontroller_3',['ModificaContattoController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_modifica_contatto_controller.html',1,'com::francesco::rubrica::Interface']]]
];
