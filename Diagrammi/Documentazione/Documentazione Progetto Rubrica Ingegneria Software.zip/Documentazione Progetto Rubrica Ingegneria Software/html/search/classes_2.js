var searchData=
[
  ['maininterfacecontroller_0',['MainInterfaceController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_main_interface_controller.html',1,'com::francesco::rubrica::Interface']]],
  ['modificacontattocontroller_1',['ModificaContattoController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_modifica_contatto_controller.html',1,'com::francesco::rubrica::Interface']]]
];
