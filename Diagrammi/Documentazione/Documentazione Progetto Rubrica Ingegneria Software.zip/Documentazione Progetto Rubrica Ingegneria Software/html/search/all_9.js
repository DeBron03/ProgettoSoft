var searchData=
[
  ['setcognome_0',['setCognome',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a0c6cfc79865cbb7c1569e6f3f16d8da8',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setcompleanno_1',['setCompleanno',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a8de45b1da0fad344ebe9f980e504ba89',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setcontatto_2',['setContatto',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_modifica_contatto_controller.html#a83047eb1c0137b3150c3e7ae5e31f9d7',1,'com.francesco.rubrica.Interface.ModificaContattoController.setContatto()'],['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_visualizza_singolo_contatto_controller.html#a18c6b290a12db5e14f40f2aed9237e83',1,'com.francesco.rubrica.Interface.VisualizzaSingoloContattoController.setContatto()']]],
  ['setemail1_3',['setEmail1',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#acebaa4e103aa15be9751d4c6db83e9f0',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setemail2_4',['setEmail2',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a74536a2c5771b103c3a4d76d66d3076b',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setemail3_5',['setEmail3',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a2386462d5235c6fc139aaf0cf314ee50',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setindirizzo_6',['setIndirizzo',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a0c5fad3b939ba0b34fb9acbb3a3abdfe',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setnome_7',['setNome',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a18be03cff3e4281397dca0b5a0eeefa6',1,'com::francesco::rubrica::Data::Contatto']]],
  ['setrubrica_8',['setRubrica',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_aggiunta_contatto_controller.html#a3c88a5f074c3def100ecb7fcac83865d',1,'com.francesco.rubrica.Interface.AggiuntaContattoController.setRubrica()'],['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_main_interface_controller.html#aaf1df3e1afeab6ddf31523eaeb38bb52',1,'com.francesco.rubrica.Interface.MainInterfaceController.setRubrica()']]],
  ['setsocietà_9',['setSocietà',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#aa681229afe412225d03979230f40a7f1',1,'com::francesco::rubrica::Data::Contatto']]],
  ['settelefono1_10',['setTelefono1',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a9c82e63d5220e0225fc416afac294f84',1,'com::francesco::rubrica::Data::Contatto']]],
  ['settelefono2_11',['setTelefono2',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a6d956d88bf96981712cb9118ac085943',1,'com::francesco::rubrica::Data::Contatto']]],
  ['settelefono3_12',['setTelefono3',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#ae7adc03806ee3fea17ecf0c3b8521d46',1,'com::francesco::rubrica::Data::Contatto']]],
  ['start_13',['start',['../classcom_1_1francesco_1_1rubrica_1_1_main_1_1_app.html#ae0d93e36de3e553d96846f5cb0b376d2',1,'com::francesco::rubrica::Main::App']]]
];
