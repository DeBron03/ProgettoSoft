var searchData=
[
  ['displayaggiungicontatto_0',['displayAggiungiContatto',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_main_interface_controller.html#a1ad5eb6cb85b3004947d85f8ea6a18d5',1,'com::francesco::rubrica::Interface::MainInterfaceController']]],
  ['displaymodificacontatto_1',['displayModificaContatto',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_visualizza_singolo_contatto_controller.html#a77fead035d90d5ae923701e23c672b6e',1,'com::francesco::rubrica::Interface::VisualizzaSingoloContattoController']]]
];
