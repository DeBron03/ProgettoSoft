var searchData=
[
  ['compareto_0',['compareTo',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a875cda9bfde691b5f49b5975ddde4a5d',1,'com::francesco::rubrica::Data::Contatto']]],
  ['contatto_1',['Contatto',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#aef9f87cff72afc38e2bfb5bceb810476',1,'com.francesco.rubrica.Data.Contatto.Contatto(String nome, String cognome)'],['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a6fa0767a7ddf0b681a162902aa27b909',1,'com.francesco.rubrica.Data.Contatto.Contatto(String nome, String cognome, String telefono1, String telefono2, String telefono3, String email1, String email2, String email3, String società, String indirizzo, LocalDate compleanno)']]]
];
