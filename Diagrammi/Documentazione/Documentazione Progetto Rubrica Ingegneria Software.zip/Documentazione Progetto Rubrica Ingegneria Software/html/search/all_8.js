var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#a5a1f977b8f298ff4ac73baec25a13ea1',1,'com::francesco::rubrica::Data::Rubrica']]],
  ['rubrica_1',['Rubrica',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html',1,'com.francesco.rubrica.Data.Rubrica'],['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#accc8e4a1a22890599b85a84ec9420e84',1,'com.francesco.rubrica.Data.Rubrica.Rubrica()']]]
];
