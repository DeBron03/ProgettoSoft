var searchData=
[
  ['aggiornadaticontatto_0',['aggiornaDatiContatto',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_visualizza_singolo_contatto_controller.html#ace5de023a9087357be1bab627c5c163e',1,'com::francesco::rubrica::Interface::VisualizzaSingoloContattoController']]],
  ['aggiungicontatto_1',['aggiungiContatto',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#aba012557630ba3d05df4ae0c9298abd3',1,'com.francesco.rubrica.Data.Rubrica.aggiungiContatto()'],['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_aggiunta_contatto_controller.html#acd18021d53cbadeff8f74938f45ef372',1,'com.francesco.rubrica.Interface.AggiuntaContattoController.aggiungiContatto()']]],
  ['aggiuntacontattocontroller_2',['AggiuntaContattoController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_aggiunta_contatto_controller.html',1,'com::francesco::rubrica::Interface']]],
  ['annulla_3',['annulla',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_aggiunta_contatto_controller.html#ac174eafe7a863fd433a3a23b61bef77f',1,'com.francesco.rubrica.Interface.AggiuntaContattoController.annulla()'],['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_modifica_contatto_controller.html#a0e906f73ef46087c83a47dff8946bdd3',1,'com.francesco.rubrica.Interface.ModificaContattoController.annulla()']]],
  ['app_4',['App',['../classcom_1_1francesco_1_1rubrica_1_1_main_1_1_app.html',1,'com::francesco::rubrica::Main']]]
];
