var searchData=
[
  ['rubrica_0',['Rubrica',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html',1,'com::francesco::rubrica::Data']]]
];
