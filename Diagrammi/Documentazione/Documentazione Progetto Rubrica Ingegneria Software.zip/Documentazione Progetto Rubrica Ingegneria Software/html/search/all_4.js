var searchData=
[
  ['getcognome_0',['getCognome',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#ac2b5fcb133390aa7217f7737232dbcee',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getcompleanno_1',['getCompleanno',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a5a93e2dcde3e84cda6155e65b053b92c',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getcontatti_2',['getContatti',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#a29dcf7eea2f15dcd81c0b71c9b55341f',1,'com::francesco::rubrica::Data::Rubrica']]],
  ['getemail1_3',['getEmail1',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a71a7b8f2570c594d6c19ccbf32e017c5',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getemail2_4',['getEmail2',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#adbe46cf9dfcee8aa8738df276dafaf86',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getemail3_5',['getEmail3',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#abc45fceef8957d3ead42489c8811c89c',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getindirizzo_6',['getIndirizzo',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a0b3f0e26af95298df85d747edae5020b',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getnome_7',['getNome',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#afb9b396e0c4b253e7e198cceb4fb32c1',1,'com::francesco::rubrica::Data::Contatto']]],
  ['getrubricacondivisa_8',['getRubricaCondivisa',['../classcom_1_1francesco_1_1rubrica_1_1_main_1_1_app.html#a9691e44f528ca14d15904ba494983119',1,'com::francesco::rubrica::Main::App']]],
  ['getsocietà_9',['getSocietà',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a225bce7bfa3c0312efefec7ca733b7d8',1,'com::francesco::rubrica::Data::Contatto']]],
  ['gettelefono1_10',['getTelefono1',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#afc016576b53db112129de1bbebcd926e',1,'com::francesco::rubrica::Data::Contatto']]],
  ['gettelefono2_11',['getTelefono2',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a8f7c6737ae615030cac8ed0fb18fcd27',1,'com::francesco::rubrica::Data::Contatto']]],
  ['gettelefono3_12',['getTelefono3',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_contatto.html#a229ff72a6893429e689f2a33e516b55d',1,'com::francesco::rubrica::Data::Contatto']]]
];
