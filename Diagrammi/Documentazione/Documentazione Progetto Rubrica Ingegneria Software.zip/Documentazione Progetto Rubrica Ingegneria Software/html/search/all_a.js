var searchData=
[
  ['visualizzasingolocontattocontroller_0',['VisualizzaSingoloContattoController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_visualizza_singolo_contatto_controller.html',1,'com::francesco::rubrica::Interface']]]
];
