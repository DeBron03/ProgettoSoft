var indexSectionsWithContent =
{
  0: "acdegimorsv",
  1: "acmrv",
  2: "acdegimors"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "Funzioni"
};

