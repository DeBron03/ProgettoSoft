var searchData=
[
  ['eliminacontatto_0',['eliminaContatto',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#a660195890ce6f9f27811b497266c499d',1,'com.francesco.rubrica.Data.Rubrica.eliminaContatto()'],['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_visualizza_singolo_contatto_controller.html#a0b8e5657281561eef1b4cc88d3caf610',1,'com.francesco.rubrica.Interface.VisualizzaSingoloContattoController.eliminaContatto()']]],
  ['esportacontatto_1',['esportaContatto',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_main_interface_controller.html#a4cda96ec0787d1c190daa44c58c97e5b',1,'com.francesco.rubrica.Interface.MainInterfaceController.esportaContatto()'],['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#a11ed4da93ae8a97714c9951f4fbc7a15',1,'com.francesco.rubrica.Data.Rubrica.esportaContatto()']]]
];
