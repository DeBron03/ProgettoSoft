var searchData=
[
  ['ordina_0',['ordina',['../classcom_1_1francesco_1_1rubrica_1_1_data_1_1_rubrica.html#acaae9ecf20a5bde071141a7dc77271c5',1,'com::francesco::rubrica::Data::Rubrica']]]
];
