var searchData=
[
  ['aggiuntacontattocontroller_0',['AggiuntaContattoController',['../classcom_1_1francesco_1_1rubrica_1_1_interface_1_1_aggiunta_contatto_controller.html',1,'com::francesco::rubrica::Interface']]],
  ['app_1',['App',['../classcom_1_1francesco_1_1rubrica_1_1_main_1_1_app.html',1,'com::francesco::rubrica::Main']]]
];
